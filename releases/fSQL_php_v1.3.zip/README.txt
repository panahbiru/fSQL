
+++++++++++++++++++++++++++++++++++++++
+
+  Flat-File SQL (fSQL)
+  Version 1.3
+
+++++++++++++++++++++++++++++++++++++++

Flat-File SQL (or fSQL) is a way to use SQL queries without having another database server (like mySQL) installed. It uses regular files that you store wherever you want. 

For usage information and documentation, please visit http://fsql.sourceforge.net

For support, please visit https://sourceforge.net/projects/fsql/
